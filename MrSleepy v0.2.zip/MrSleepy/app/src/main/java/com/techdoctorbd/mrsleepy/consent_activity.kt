package com.techdoctorbd.mrsleepy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class consent_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consent)

        val ImageButton = findViewById<ImageButton>(R.id.TapAnywhere)

        ImageButton.setOnClickListener {
            val intent = Intent(this, SetActivity::class.java)

            startActivity(intent)
        }
    }
}